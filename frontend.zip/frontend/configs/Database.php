<?php

class Database
{
  //const DB_DSN = 'mysql:host=localhost;dbname=PHP0721E_nhom3;charset=utf8';
  //const DB_USERNAME = 'root';
 // const DB_PASSWORD = '';

   const DB_DSN = 'mysql:host=localhost;dbname=PHP0721E_nhom3;charset=utf8';
   const DB_USERNAME = 'PHP0721E_nhom3';
   const DB_PASSWORD = '123456';
  
}
