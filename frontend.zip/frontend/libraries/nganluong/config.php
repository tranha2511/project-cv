<?php
define('URL_API','https://www.nganluong.vn/checkout.api.nganluong.post.php'); // Đường dẫn gọi api
define('RECEIVER','demo@nganluong.vn'); // Email tài khoản ngân lượng
define('MERCHANT_ID', '36680'); // Mã merchant kết nối
define('MERCHANT_PASS', 'matkhauketnoi'); // Mật khẩu kết nôi
?>
