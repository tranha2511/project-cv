<div class="container" style="margin: 70px">
    <h1>Cảm ơn bạn đã đặt hàng tại <span style="font-style: italic; font-weight: bold">TrnHa Store</span>!</h1>
</div>