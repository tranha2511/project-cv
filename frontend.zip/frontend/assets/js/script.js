$(document).ready(function(){
        $('.btn-menu-mobile').click(function(){
            $('.ul-mobile').toggleClass('show');
        });
    });